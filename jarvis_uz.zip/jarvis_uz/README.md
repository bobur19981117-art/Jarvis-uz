# JARVIS UZ

O'zbek tilida ovozli Android AI yordamchi. Flutter, speech-to-text, TTS, Gemini/OpenAI API.

## Ishga tushirish
1. Flutter SDK o'rnating.
2. Loyihani oching.
3. `.env.example` faylidan `.env` yarating yoki mavjud `.env` ni tahrirlang.
4. API kalitini kiriting.
5. `flutter pub get`
6. Android telefon yoki emulator ulang.
7. `flutter run`

## Android
- Android 10+ uchun mos.
- Mikrofon va internet ruxsatlari AndroidManifest.xml ichida qo'shilgan.
