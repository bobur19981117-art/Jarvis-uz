package com.example.jarvis_uz

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
