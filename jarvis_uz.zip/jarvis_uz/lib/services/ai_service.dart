import 'dart:convert';

import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;

enum AiProvider { gemini, openai }

class AiService {
  AiService() {
    final provider = dotenv.env['AI_PROVIDER']?.trim().toLowerCase();
    _provider = provider == 'openai' ? AiProvider.openai : AiProvider.gemini;
  }

  late final AiProvider _provider;

  Future<String> ask(String prompt) async {
    final systemPrompt =
        "Sen JARVIS nomli aqlli yordamchisan. Faqat o'zbek tilida, aniq, foydali va muloyim javob ber. "
        "Agar foydalanuvchi ovozli buyruq bersa, qisqa va amaliy javob qaytar.";

    if (_provider == AiProvider.openai) {
      return _askOpenAi(systemPrompt, prompt);
    }
    return _askGemini(systemPrompt, prompt);
  }

  Future<String> _askGemini(String systemPrompt, String prompt) async {
    final apiKey = dotenv.env['GEMINI_API_KEY'];
    if (apiKey == null || apiKey.isEmpty || apiKey == 'YOUR_GEMINI_API_KEY') {
      return "Gemini API kaliti topilmadi. Iltimos, .env faylida GEMINI_API_KEY ni kiriting.";
    }

    final uri = Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey',
    );

    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'systemInstruction': {
          'parts': [
            {'text': systemPrompt}
          ]
        },
        'contents': [
          {
            'role': 'user',
            'parts': [
              {'text': prompt}
            ]
          }
        ],
        'generationConfig': {
          'temperature': 0.7,
          'maxOutputTokens': 700,
        }
      }),
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      return 'Gemini xatosi: ${response.statusCode}. ${response.body}';
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final candidates = data['candidates'] as List<dynamic>?;
    final parts = candidates?.firstOrNull?['content']?['parts'] as List<dynamic>?;
    final text = parts?.map((e) => e['text'] ?? '').join('\n').trim();
    return (text == null || text.isEmpty) ? 'Javob topilmadi.' : text;
  }

  Future<String> _askOpenAi(String systemPrompt, String prompt) async {
    final apiKey = dotenv.env['OPENAI_API_KEY'];
    if (apiKey == null || apiKey.isEmpty || apiKey == 'YOUR_OPENAI_API_KEY') {
      return "OpenAI API kaliti topilmadi. Iltimos, .env faylida OPENAI_API_KEY ni kiriting.";
    }

    final response = await http.post(
      Uri.parse('https://api.openai.com/v1/chat/completions'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode({
        'model': 'gpt-4o-mini',
        'messages': [
          {'role': 'system', 'content': systemPrompt},
          {'role': 'user', 'content': prompt},
        ],
        'temperature': 0.7,
        'max_tokens': 700,
      }),
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      return 'OpenAI xatosi: ${response.statusCode}. ${response.body}';
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final choices = data['choices'] as List<dynamic>?;
    final text = choices?.firstOrNull?['message']?['content']?.toString().trim();
    return (text == null || text.isEmpty) ? 'Javob topilmadi.' : text;
  }
}
