import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart';

import 'services/ai_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: '.env');
  runApp(const JarvisApp());
}

class JarvisApp extends StatelessWidget {
  const JarvisApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'JARVIS UZ',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF020713),
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00B7FF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const JarvisHomePage(),
    );
  }
}

class ChatMessage {
  const ChatMessage({required this.text, required this.isUser});
  final String text;
  final bool isUser;
}

class JarvisHomePage extends StatefulWidget {
  const JarvisHomePage({super.key});

  @override
  State<JarvisHomePage> createState() => _JarvisHomePageState();
}

class _JarvisHomePageState extends State<JarvisHomePage>
    with SingleTickerProviderStateMixin {
  final SpeechToText _speech = SpeechToText();
  final FlutterTts _tts = FlutterTts();
  final AiService _aiService = AiService();
  final TextEditingController _textController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  late final AnimationController _animationController;

  bool _speechReady = false;
  bool _isListening = false;
  bool _isThinking = false;
  String _status = 'JARVIS tayyorlanmoqda...';
  String _recognizedText = '';

  final List<ChatMessage> _messages = const [
    ChatMessage(
      text: "Assalomu alaykum! Men JARVIS UZ. Mikrofonni bosing yoki matn yozing.",
      isUser: false,
    ),
  ].toList();

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
    _initJarvis();
  }

  Future<void> _initJarvis() async {
    await Permission.microphone.request();
    await _configureTts();
    final available = await _speech.initialize(
      onStatus: (status) {
        if (!mounted) return;
        setState(() {
          _status = _statusText(status);
          _isListening = status == 'listening';
        });
      },
      onError: (error) {
        if (!mounted) return;
        setState(() {
          _status = 'Ovoz tanishda xato: ${error.errorMsg}';
          _isListening = false;
        });
      },
    );

    if (!mounted) return;
    setState(() {
      _speechReady = available;
      _status = available
          ? 'Tayyor. Gapirish uchun mikrofonni bosing.'
          : 'Ovoz tanish xizmati mavjud emas.';
    });
  }

  Future<void> _configureTts() async {
    await _tts.setLanguage('uz-UZ');
    await _tts.setSpeechRate(0.48);
    await _tts.setPitch(0.95);
    await _tts.setVolume(1.0);
  }

  String _statusText(String raw) {
    switch (raw) {
      case 'listening':
        return 'Eshitmoqdaman...';
      case 'notListening':
        return 'Tayyor.';
      case 'done':
        return 'Ovoz qabul qilindi.';
      default:
        return raw;
    }
  }

  Future<void> _toggleListening() async {
    if (!_speechReady) {
      await _initJarvis();
      return;
    }

    if (_isListening) {
      await _speech.stop();
      if (_recognizedText.trim().isNotEmpty) {
        await _sendPrompt(_recognizedText.trim());
      }
      return;
    }

    setState(() {
      _recognizedText = '';
      _status = 'Eshitmoqdaman...';
      _isListening = true;
    });

    await _speech.listen(
      localeId: 'uz_UZ',
      listenMode: ListenMode.confirmation,
      partialResults: true,
      listenFor: const Duration(seconds: 25),
      pauseFor: const Duration(seconds: 3),
      onResult: _onSpeechResult,
    );
  }

  void _onSpeechResult(SpeechRecognitionResult result) {
    setState(() {
      _recognizedText = result.recognizedWords;
    });

    if (result.finalResult && result.recognizedWords.trim().isNotEmpty) {
      _speech.stop();
      _sendPrompt(result.recognizedWords.trim());
    }
  }

  Future<void> _sendPrompt(String prompt) async {
    if (prompt.trim().isEmpty || _isThinking) return;
    FocusScope.of(context).unfocus();
    _textController.clear();

    setState(() {
      _messages.add(ChatMessage(text: prompt, isUser: true));
      _isThinking = true;
      _status = 'JARVIS o‘ylamoqda...';
      _recognizedText = '';
    });
    _scrollToBottom();

    try {
      final answer = await _aiService.ask(prompt);
      if (!mounted) return;
      setState(() {
        _messages.add(ChatMessage(text: answer, isUser: false));
        _status = 'Javob tayyor.';
      });
      _scrollToBottom();
      await _speak(answer);
    } catch (e) {
      final errorText = 'Xato yuz berdi: $e';
      if (!mounted) return;
      setState(() {
        _messages.add(ChatMessage(text: errorText, isUser: false));
        _status = 'Xato.';
      });
    } finally {
      if (mounted) {
        setState(() => _isThinking = false);
      }
    }
  }

  Future<void> _speak(String text) async {
    final cleaned = text
        .replaceAll(RegExp(r'[*_`#>\[\]()]'), '')
        .replaceAll(RegExp(r'https?://\S+'), 'havola');
    await _tts.stop();
    await _tts.speak(cleaned);
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 120), () {
      if (!_scrollController.hasClients) return;
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOut,
      );
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    _speech.stop();
    _tts.stop();
    _textController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.15,
            colors: [Color(0xFF063E68), Color(0xFF020713), Color(0xFF00030A)],
            stops: [0.0, 0.55, 1.0],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _Header(status: _status),
              const SizedBox(height: 6),
              SizedBox(
                height: 230,
                child: Center(
                  child: JarvisCore(
                    controller: _animationController,
                    active: _isListening || _isThinking,
                  ),
                ),
              ),
              if (_recognizedText.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: Text(
                    'Siz: $_recognizedText',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Color(0xFF7FE7FF)),
                  ),
                ),
              Expanded(
                child: ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                  itemCount: _messages.length,
                  itemBuilder: (context, index) {
                    final msg = _messages[index];
                    return _MessageBubble(message: msg);
                  },
                ),
              ),
              _InputBar(
                controller: _textController,
                isListening: _isListening,
                isThinking: _isThinking,
                onMic: _toggleListening,
                onSend: () => _sendPrompt(_textController.text.trim()),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.status});
  final String status;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 6),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.04),
          border: Border.all(color: const Color(0xFF00B7FF).withOpacity(0.35)),
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF00B7FF).withOpacity(0.16),
              blurRadius: 28,
              spreadRadius: 2,
            )
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 12,
              height: 12,
              decoration: const BoxDecoration(
                color: Color(0xFF00F0FF),
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: Color(0xFF00F0FF), blurRadius: 12)],
              ),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'JARVIS UZ',
                    style: TextStyle(
                      letterSpacing: 4,
                      fontWeight: FontWeight.w800,
                      fontSize: 22,
                      color: Color(0xFFE8FBFF),
                    ),
                  ),
                  Text(
                    'Ovozli sun’iy intellekt yordamchisi',
                    style: TextStyle(color: Color(0xFF7EAFC4), fontSize: 12),
                  ),
                ],
              ),
            ),
            Flexible(
              child: Text(
                status,
                textAlign: TextAlign.right,
                style: const TextStyle(color: Color(0xFF7FE7FF), fontSize: 12),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class JarvisCore extends StatelessWidget {
  const JarvisCore({super.key, required this.controller, required this.active});
  final AnimationController controller;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) {
        return CustomPaint(
          size: const Size(230, 230),
          painter: _JarvisPainter(
            progress: controller.value,
            active: active,
          ),
        );
      },
    );
  }
}

class _JarvisPainter extends CustomPainter {
  _JarvisPainter({required this.progress, required this.active});
  final double progress;
  final bool active;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = math.min(size.width, size.height) / 2;
    final glow = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFF00D9FF).withOpacity(active ? 0.62 : 0.38),
          const Color(0xFF0066FF).withOpacity(0.16),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(center: center, radius: radius));
    canvas.drawCircle(center, radius * 0.95, glow);

    for (int i = 0; i < 4; i++) {
      final angle = progress * 2 * math.pi * (i.isEven ? 1 : -1) + i * 0.6;
      final rect = Rect.fromCircle(center: center, radius: radius * (0.78 - i * 0.11));
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = i == 0 ? 3.0 : 1.7
        ..strokeCap = StrokeCap.round
        ..color = Color.lerp(
          const Color(0xFF00E5FF),
          const Color(0xFF1C6DFF),
          i / 4,
        )!.withOpacity(0.95);
      canvas.drawArc(rect, angle, math.pi * (0.55 + i * 0.11), false, paint);
      canvas.drawArc(rect, angle + math.pi, math.pi * 0.35, false, paint);
    }

    final gridPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.7
      ..color = const Color(0xFF00B7FF).withOpacity(0.22);
    for (int i = 1; i <= 3; i++) {
      canvas.drawCircle(center, radius * i / 4, gridPaint);
    }
    canvas.drawLine(Offset(center.dx, center.dy - radius * 0.78),
        Offset(center.dx, center.dy + radius * 0.78), gridPaint);
    canvas.drawLine(Offset(center.dx - radius * 0.78, center.dy),
        Offset(center.dx + radius * 0.78, center.dy), gridPaint);

    final pulseRadius = radius * (0.22 + 0.06 * math.sin(progress * 2 * math.pi));
    final corePaint = Paint()
      ..shader = const RadialGradient(
        colors: [Color(0xFFFFFFFF), Color(0xFF00E5FF), Color(0xFF003CFF)],
      ).createShader(Rect.fromCircle(center: center, radius: pulseRadius));
    canvas.drawCircle(center, pulseRadius, corePaint);

    final dotPaint = Paint()..color = const Color(0xFFBFF8FF);
    for (int i = 0; i < 18; i++) {
      final a = i * math.pi * 2 / 18 + progress * math.pi * 2;
      final r = radius * (0.58 + 0.18 * math.sin(progress * 2 * math.pi + i));
      canvas.drawCircle(center + Offset(math.cos(a) * r, math.sin(a) * r), 2.0, dotPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _JarvisPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.active != active;
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({required this.message});
  final ChatMessage message;

  @override
  Widget build(BuildContext context) {
    final isUser = message.isUser;
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: isUser
              ? const Color(0xFF005DFF).withOpacity(0.22)
              : const Color(0xFF06223A).withOpacity(0.72),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18),
            topRight: const Radius.circular(18),
            bottomLeft: Radius.circular(isUser ? 18 : 4),
            bottomRight: Radius.circular(isUser ? 4 : 18),
          ),
          border: Border.all(
            color: isUser
                ? const Color(0xFF2E8BFF).withOpacity(0.55)
                : const Color(0xFF00D9FF).withOpacity(0.33),
          ),
        ),
        child: Text(
          message.text,
          style: const TextStyle(fontSize: 15.5, height: 1.35, color: Color(0xFFE9FBFF)),
        ),
      ),
    );
  }
}

class _InputBar extends StatelessWidget {
  const _InputBar({
    required this.controller,
    required this.isListening,
    required this.isThinking,
    required this.onMic,
    required this.onSend,
  });

  final TextEditingController controller;
  final bool isListening;
  final bool isThinking;
  final VoidCallback onMic;
  final VoidCallback onSend;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(14, 8, 14, 14 + MediaQuery.of(context).padding.bottom),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: controller,
              minLines: 1,
              maxLines: 4,
              textInputAction: TextInputAction.send,
              onSubmitted: (_) => onSend(),
              decoration: InputDecoration(
                hintText: "Buyruq yozing...",
                hintStyle: const TextStyle(color: Color(0xFF6995AA)),
                filled: true,
                fillColor: Colors.white.withOpacity(0.06),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide(color: const Color(0xFF00B7FF).withOpacity(0.28)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: const BorderSide(color: Color(0xFF00D9FF), width: 1.5),
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          _RoundActionButton(
            icon: isListening ? Icons.stop_rounded : Icons.mic_rounded,
            glowing: isListening,
            onTap: isThinking ? null : onMic,
          ),
          const SizedBox(width: 10),
          _RoundActionButton(
            icon: Icons.send_rounded,
            glowing: false,
            onTap: isThinking ? null : onSend,
          ),
        ],
      ),
    );
  }
}

class _RoundActionButton extends StatelessWidget {
  const _RoundActionButton({required this.icon, required this.glowing, this.onTap});
  final IconData icon;
  final bool glowing;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 240),
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            colors: glowing
                ? [const Color(0xFF00F0FF), const Color(0xFF0066FF)]
                : [const Color(0xFF083F70), const Color(0xFF031A31)],
          ),
          border: Border.all(color: const Color(0xFF7FE7FF).withOpacity(0.55)),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF00B7FF).withOpacity(glowing ? 0.55 : 0.18),
              blurRadius: glowing ? 24 : 12,
            ),
          ],
        ),
        child: Icon(icon, color: Colors.white),
      ),
    );
  }
}
